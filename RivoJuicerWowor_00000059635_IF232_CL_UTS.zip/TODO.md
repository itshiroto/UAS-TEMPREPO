[x] Tampilkan Data Kontak
    [x] Tampilkan tabel
        [ ] Tambah fitur kontak penting (bikin linked list terpisah)
    [x] Tampilkan Detail
[ ] File Processing
    [x] Read File 
    [ ] Write File
[ ] Kontak penting
[ ] About me
    [ ] Detail kontak dan Paragraf (liat di soal)
    [ ] Implementasi edit about me
[ ] Error Handling
[ ] Besarin structnya